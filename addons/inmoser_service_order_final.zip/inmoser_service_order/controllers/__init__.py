# -*- coding: utf-8 -*-

from . import client_portal
