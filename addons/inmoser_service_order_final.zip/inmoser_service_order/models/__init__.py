# -*- coding: utf-8 -*-

from . import res_partner_extension
from . import hr_employee_extension
from . import service_equipment
from . import service_type
from . import service_order
from . import service_order_refaction_line
from . import service_order_business_logic
from . import qr_code_generator
from . import account_integration
from . import stock_integration
from . import hr_integration
